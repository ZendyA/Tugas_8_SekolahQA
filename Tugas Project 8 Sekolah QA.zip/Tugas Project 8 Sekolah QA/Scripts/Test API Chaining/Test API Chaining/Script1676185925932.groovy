import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

responseGetUser = WS.sendRequest(findTestObject('Admin/Get User'))

WS.verifyResponseStatusCode(responseGetUser, 200)

def slurperGetUser = new groovy.json.JsonSlurper()

def resultGetUser = slurperGetUser.parseText(responseGetUser.getResponseBodyContent())

String apiPostLoanResponseGetUser = responseGetUser.getResponseText()

def valueGetUser = resultGetUser.employeeId

GlobalVariable.id = valueGetUser

WS.sendRequestAndVerify(findTestObject('Admin/Get User', [('employeeId') : GlobalVariable.id]))

String JsonGetUser = '\n\t{\n\t"$schema": "https://json-schema.org/draft/2019-09/schema",\n\t"$id": "http://example.com/example.json",\n\t"type": "object",\n\t"default": {},\n\t"title": "Root Schema",\n\t"required": [\n\t\t"data",\n\t\t"rels"\n\t],\n\t"properties": {\n\t\t"data": {\n\t\t\t"type": "array",\n\t\t\t"default": [],\n\t\t\t"title": "The data Schema",\n\t\t\t"items": {\n\t\t\t\t"type": "object",\n\t\t\t\t"default": {},\n\t\t\t\t"title": "A Schema",\n\t\t\t\t"required": [\n\t\t\t\t\t"userName",\n\t\t\t\t\t"userRole",\n\t\t\t\t\t"status",\n\t\t\t\t\t"employeeName",\n\t\t\t\t\t"employeeId"\n\t\t\t\t],\n\t\t\t\t"properties": {\n\t\t\t\t\t"userName": {\n\t\t\t\t\t\t"type": "string",\n\t\t\t\t\t\t"default": "",\n\t\t\t\t\t\t"title": "The userName Schema",\n\t\t\t\t\t\t"examples": [\n\t\t\t\t\t\t\t"ajaditanya123"\n\t\t\t\t\t\t]\n\t\t\t\t\t},\n\t\t\t\t\t"userRole": {\n\t\t\t\t\t\t"type": "string",\n\t\t\t\t\t\t"default": "",\n\t\t\t\t\t\t"title": "The userRole Schema",\n\t\t\t\t\t\t"examples": [\n\t\t\t\t\t\t\t"Admin"\n\t\t\t\t\t\t]\n\t\t\t\t\t},\n\t\t\t\t\t"status": {\n\t\t\t\t\t\t"type": "string",\n\t\t\t\t\t\t"default": "",\n\t\t\t\t\t\t"title": "The status Schema",\n\t\t\t\t\t\t"examples": [\n\t\t\t\t\t\t\t"Enabled"\n\t\t\t\t\t\t]\n\t\t\t\t\t},\n\t\t\t\t\t"employeeName": {\n\t\t\t\t\t\t"type": "string",\n\t\t\t\t\t\t"default": "",\n\t\t\t\t\t\t"title": "The employeeName Schema",\n\t\t\t\t\t\t"examples": [\n\t\t\t\t\t\t\t"aja ditanya (Past Employee)"\n\t\t\t\t\t\t]\n\t\t\t\t\t},\n\t\t\t\t\t"employeeId": {\n\t\t\t\t\t\t"type": "string",\n\t\t\t\t\t\t"default": "",\n\t\t\t\t\t\t"title": "The employeeId Schema",\n\t\t\t\t\t\t"examples": [\n\t\t\t\t\t\t\t"113"\n\t\t\t\t\t\t]\n\t\t\t\t\t}\n\t\t\t\t},\n\t\t\t\t"examples": [{\n\t\t\t\t\t"userName": "ajaditanya123",\n\t\t\t\t\t"userRole": "Admin",\n\t\t\t\t\t"status": "Enabled",\n\t\t\t\t\t"employeeName": "aja ditanya (Past Employee)",\n\t\t\t\t\t"employeeId": "113"\n\t\t\t\t}]\n\t\t\t},\n\t\t\t"examples": [\n\t\t\t\t[{\n\t\t\t\t\t"userName": "ajaditanya123",\n\t\t\t\t\t"userRole": "Admin",\n\t\t\t\t\t"status": "Enabled",\n\t\t\t\t\t"employeeName": "aja ditanya (Past Employee)",\n\t\t\t\t\t"employeeId": "113"\n\t\t\t\t}]\n\t\t\t]\n\t\t},\n\t\t"rels": {\n\t\t\t"type": "array",\n\t\t\t"default": [],\n\t\t\t"title": "The rels Schema",\n\t\t\t"items": {},\n\t\t\t"examples": [\n\t\t\t\t[]\n\t\t\t]\n\t\t}\n\t},\n\t"examples": [{\n\t\t"data": [{\n\t\t\t"userName": "ajaditanya123",\n\t\t\t"userRole": "Admin",\n\t\t\t"status": "Enabled",\n\t\t\t"employeeName": "aja ditanya (Past Employee)",\n\t\t\t"employeeId": "113"\n\t\t}],\n\t\t"rels": []\n\t}]\n}\n'

boolean successfulGetUser = WS.validateJsonAgainstSchema(responseGetUser, JsonGetUser)

responseLoginAdmin = WS.sendRequest(findTestObject('Admin/Login Admin'))

WS.verifyResponseStatusCode(responseLoginAdmin, 200)

def slurperLoginAdmin = new groovy.json.JsonSlurper()

def resultLoginAdmin = slurperLoginAdmin.parseText(responseLoginAdmin.getResponseBodyContent())

String apiPostLoanResponseLoginAdmin = responseLoginAdmin.getResponseText()

def valueLoginAdmin = resultLoginAdmin.employeeId

GlobalVariable.id = valueLoginAdmin

WS.sendRequestAndVerify(findTestObject('Admin/Login Admin', [('employeeId') : GlobalVariable.id]))

String JsonLoginAdmin = '\n{\n    "$schema": "https://json-schema.org/draft/2019-09/schema",\n    "$id": "http://example.com/example.json",\n    "type": "object",\n    "default": {},\n    "title": "Root Schema",\n    "required": [\n        "login",\n        "user"\n    ],\n    "properties": {\n        "login": {\n            "type": "boolean",\n            "default": false,\n            "title": "The login Schema",\n            "examples": [\n                true\n            ]\n        },\n        "user": {\n            "type": "object",\n            "default": {},\n            "title": "The user Schema",\n            "required": [\n                "userName",\n                "userRole",\n                "status",\n                "employeeName",\n                "employeeId"\n            ],\n            "properties": {\n                "userName": {\n                    "type": "string",\n                    "default": "",\n                    "title": "The userName Schema",\n                    "examples": [\n                        "tester"\n                    ]\n                },\n                "userRole": {\n                    "type": "string",\n                    "default": "",\n                    "title": "The userRole Schema",\n                    "examples": [\n                        "ESS"\n                    ]\n                },\n                "status": {\n                    "type": "string",\n                    "default": "",\n                    "title": "The status Schema",\n                    "examples": [\n                        "Enabled"\n                    ]\n                },\n                "employeeName": {\n                    "type": "string",\n                    "default": "",\n                    "title": "The employeeName Schema",\n                    "examples": [\n                        "tester tester"\n                    ]\n                },\n                "employeeId": {\n                    "type": "string",\n                    "default": "",\n                    "title": "The employeeId Schema",\n                    "examples": [\n                        "4"\n                    ]\n                }\n            },\n            "examples": [{\n                "userName": "tester",\n                "userRole": "ESS",\n                "status": "Enabled",\n                "employeeName": "tester tester",\n                "employeeId": "4"\n            }]\n        }\n    },\n    "examples": [{\n        "login": true,\n        "user": {\n            "userName": "tester",\n            "userRole": "ESS",\n            "status": "Enabled",\n            "employeeName": "tester tester",\n            "employeeId": "4"\n        }\n    }]\n}\n'

boolean successfulLoginAdmin = WS.validateJsonAgainstSchema(responseLoginAdmin, JsonLoginAdmin)

responseAdd = WS.sendRequest(findTestObject('Employee/Add Employee'))

WS.verifyResponseStatusCode(responseAdd, 200)

def slurperAdd = new groovy.json.JsonSlurper()

def resultAdd = slurperAdd.parseText(responseAdd.getResponseBodyContent())

String apiPostLoanResponseAdd = responseAdd.getResponseText()

def valueAdd = resultAdd.id

GlobalVariable.id = valueAdd

WS.verifyElementPropertyValue(responseAdd, 'success', 'Successfully Saved')

responseIn = WS.sendRequest(findTestObject('Punch/Punch In'))

WS.verifyResponseStatusCode(responseIn, 200)

WS.verifyElementPropertyValue(responseIn, 'success', 'Successfully Punched In')

responseDetails = WS.sendRequest(findTestObject('Employee/Employee Details'))

WS.verifyResponseStatusCode(responseDetails, 200)

def slurperDetails = new groovy.json.JsonSlurper()

def resultDetails = slurperDetails.parseText(responseDetails.getResponseBodyContent())

String apiPostLoanResponseDetails = responseDetails.getResponseText()

def valueDetails = resultAdd.employeeId

GlobalVariable.employeeId = valueDetails

GlobalVariable.nationality = 'Indonesian'

WS.sendRequestAndVerify(findTestObject('Employee/Employee Details', [('employeeId') : GlobalVariable.employeeId]))

responseSearch = WS.sendRequest(findTestObject('Employee/Search Employee'))

WS.verifyResponseStatusCode(responseSearch, 200)

WS.sendRequestAndVerify(findTestObject('Employee/Search Employee', [('employeeId') : GlobalVariable.employeeId]))

responseUpdate = WS.sendRequest(findTestObject('Employee/Update Employee Detail'))

WS.verifyResponseStatusCode(responseUpdate, 200)

WS.verifyElementPropertyValue(responseUpdate, 'success', 'Successfully Updated')

responseDetails1 = WS.sendRequest(findTestObject('Employee/Employee Details'))

WS.verifyResponseStatusCode(responseDetails1, 200)

def slurperDetails1 = new groovy.json.JsonSlurper()

def resultDetails1 = slurperDetails.parseText(responseDetails1.getResponseBodyContent())

String apiPostLoanResponseDetails1 = responseDetails1.getResponseText()

def valueDetails1 = resultDetails1.data.nationality

GlobalVariable.nationality = valueDetails1

WS.sendRequestAndVerify(findTestObject('Employee/Employee Details', [('nationality') : GlobalVariable.nationality]))

responseOut = WS.sendRequest(findTestObject('Punch/Punch Out'))

WS.verifyResponseStatusCode(responseOut, 200)

WS.verifyElementPropertyValue(responseOut, 'success', 'Successfully Punched Out')

responseTerminate = WS.sendRequest(findTestObject('Employee/Terminate Employee'))

WS.verifyResponseStatusCode(responseTerminate, 200)

WS.verifyElementPropertyValue(responseTerminate, 'success', 'Successfully Terminated')

